#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
#include"Record.h"
FILE *f1; 
void fileselc()
{
	srand(time(NULL));
	int a=rand()%4;
	clock_t start,end;
	switch(a)
	{
		case 0:
			f1=fopen("chess.txt","r");
			break;
		case 1:
			f1=fopen("castling.txt","r");
			break;
		case 2:
			f1=fopen("dennis.txt","r");
			break;
		case 3:
			f1=fopen("chessrules.txt","r");
			break;
		case 4:
			f1=fopen("queen.txt","r");
			break;
	}
}
char instructions()
{
	char opt;
	printf("\nType given paragraph without errors");
	printf("\nNotice:Please don't skip any character");
	printf("\nSkiping a character can harm all your further progress");
	printf("\nPress ENTER to submit the test");
	printf("\nAre You Ready(Y/N)??\n");
	scanf(" %c",&opt);
	return opt;
}
void start()
{
	int i,j;
	printf("\nReady\a");
	for(i=0;i<50000;i++)
		for(j=0;j<15000;j++);
	printf("\nSet\a");
	for(i=0;i<50000;i++)
		for(j=0;j<15000;j++);
	printf("\nGo.....(Start typing)\n\a");

}
char *oparashow()
{
	fileselc();
	int i=0;
	char a;
	char *t=(char *)malloc(500*sizeof(char));
	while((a=getc(f1))!=EOF)
	{
		t[i]=a;
		i++;
	}
	t[i]='\0';
	return t;
}
int cmp(char *a,char *b)
{
	int i=0;
	int cnt=0;
	for(i=0;a[i]!='\0';i++)
	{
		if(a[i]!=b[i])
			cnt++;
	}
	return cnt;
}
int getcount(char *b)
{
	return strlen(b);
}
int valid(int a,int b)
{
	return (a-b<10);
}

int main()
{
	int i,j;
	char *a,*b=(char *)malloc(500*sizeof(char)),*c=(char *)malloc(15*sizeof(char));
	char tmp;
	float temp;
	int cnt;
	float time;
	float ts;
	int count,res;
	float itime;
	float score;
	REC *record;
	int rank;
	clock_t st,end;	
	printf("\nEnter Your name\n");
	scanf("%s",c);
	a=oparashow();
	tmp=instructions();
	if(tmp=='n'||tmp=='N')
	{
		printf("\nThanks!!!!");
		return 0;	
	}	
	start();
	puts(a);
	fflush(stdin);
	st=clock();
	gets(b);
	end=clock();
	cnt=cmp(a,b);
	count=getcount(b);
	if(valid(strlen(a),count)==0)
	{
		printf("\nYou have not typed enough to get score\n");
		printf("Thank you!!!");
		return 0;
	}
	itime=(float)cntwords(a);
	time=(float)(end-st)/CLOCKS_PER_SEC;
	printf("\nYou typed the whole paragraph in %f seconds with %d errors.",time,cnt);
	temp=pow(2.303,(float)cnt/200);
	time=time*temp;
	score=itime/time*100*4/6;
	res=newput(c,score,&ts,&rank);
	if(res==2)
	{
		printf("\n\nScore:-%f",score);
		printf("\nYour Personal Highest:-%f",ts);
		printf("\nYour best rank:-%d",rank);	
	}	
	else
	{
		printf("\n\nPERSONAL HIGHEST!!!");
		printf("\nYour score :- %f",score);
		printf("\nYour rank :- %d",rank);
	}
	printf("\nType L to see full ranklist. Type any other key to exit\n");
	scanf(" %c",&tmp);
	if(tmp=='l'||tmp=='L')
		print();
	printf("\nThank you!!!!!!");
}
int cntwords(char *t)
{
	int i;
	int cnt=1;
	for(i=0;t[i]!='\0';i++)
	{
		if(t[i]==32)
			cnt++;
	}
	return cnt;
}
