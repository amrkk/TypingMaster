#include<stdlib.h>
#include<stdio.h>
typedef struct record
{
	char nm[20];
	float score;
}REC;
typedef struct node
{
	REC data;
	struct node * next;
	struct node *prev;
}NODE;
NODE *createNode(REC n)
{
	NODE *a=(NODE *)malloc(sizeof(NODE));
	a->data=n;
	a->next=NULL;
	a->prev=NULL;
	return a;
}
void add(NODE **head,NODE *pPre,NODE *pNext,REC n)
{
	NODE *pLoc=createNode(n);
	if(pPre==NULL)
	{
		pLoc->next=*head;
		if(*head!=NULL)
			(*head)->prev=pLoc;
		*head=pLoc;
	}
	else
	{
		pLoc->next=pPre->next;
		pLoc->prev=pPre;
		if(pNext!=NULL)
			pNext->prev=pLoc;
		pPre->next=pLoc;
	}
}
void traverse(NODE **head,NODE **pPre,NODE **pNext,int pos)
{
	NODE *a=*head,*b;
	int cnt=1;
	while(a!=NULL)
	{
		if(cnt==pos)
			break;
		cnt++;
		b=a;
		a=a->next;
	}
	if(*head==NULL)
	{
		*pPre=NULL;
		*pNext=NULL;
	}
	else if(a!=NULL)
	{
		*pPre=a->prev;
		*pNext=a->next;
	}
	else
	{
		*pPre=b;
		*pNext=NULL;
	}
}
void insert(NODE **head,int pos,REC data)
{
	NODE *a,*pPre,*pNext;
	traverse(head,&pPre,&pNext,pos);
	add(head,pPre,pNext,data);
}
int getcnt(NODE *head)
{
	NODE *a=head;
	int cnt=0;
	while(a!=NULL)
	{
		cnt++;
		a=a->next;
	}
	return cnt;
}
int search(NODE *head,char *nm)
{
	NODE *a=head;
	REC tmp;
	while(a!=NULL)
	{
		tmp=a->data;
		if(strcmp(tmp.nm,nm)==0)
			break;
		a=a->next;
	}
	if(a==NULL)
		return 0;
	return 1;
}
