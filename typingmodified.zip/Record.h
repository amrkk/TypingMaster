#include<stdio.h>
#include<string.h>
#include"DLISTtype.h"
REC *createRec(char *a,float b)
{
	REC *x=(REC *)malloc(sizeof(REC));
	strcpy(x->nm,a);
	x->score=b;
	return x;
}
void displayNode(REC a)
{
	printf("    %-15s",a.nm);
	printf("%.2f",a.score);
}
void print()
{
	FILE *f1;
	int i=1;
	REC tmp;
	f1=fopen("Newfile.dat","rb");
	printf("\nRank   Name           Speed[Wpm]\n");
	for(;;i++)
	{
			fread(&tmp,sizeof(REC),1,f1);
			if(feof(f1))
				break;
			printf("\n%3d",i);
			displayNode(tmp);
	}
	fclose(f1);
}
int newput(char *nm,float score,float *ts,int *rank)
{
	FILE *f1;
	NODE *top1=NULL,*top2=NULL;
	int flg=0;
	REC a;
	int cnt=1;
	f1=fopen("Newfile.dat","rb+");
	if(f1==NULL)
	{
		fclose(f1);
		f1=fopen("Newfile.dat","wb");
		fclose(f1);
		f1=fopen("Newfile.dat","rb+");
	}
	while(1)
	{
		fread(&a,sizeof(REC),1,f1);
		if(feof(f1))
			break;
		if(score>a.score)
		{
			flg=1;
			break;
		}
		if(strcmp(a.nm,nm)==0)
		{
			*ts=a.score;
			flg=2;
			*rank=cnt;
			break;
		}
		insert(&top1,cnt++,a);
	}
	*rank=cnt;
	if(flg==2)
	{	
		fclose(f1);
		return flg;
	}
	strcpy(a.nm,nm);
	a.score=score;
	if(flg==0)
	{
		fclose(f1);
		f1=fopen("Newfile.dat","ab");
		fwrite(&a,sizeof(REC),1,f1);
		fclose(f1);
		return flg;
	}
	insert(&top1,cnt++,a);
	cnt=1;
	while(1)
	{
		fread(&a,sizeof(REC),1,f1);
		if(feof(f1))
			break;
		if(strcmp(a.nm,nm)==0)
			continue;
		insert(&top2,cnt++,a);
	}
	fclose(f1);
	f1=fopen("Newfile.dat","wb");
	while(top1!=NULL)
	{
		a=top1->data;
		fwrite(&a,sizeof(REC),1,f1);
		top1=top1->next;
	}
	while(top2!=NULL)
	{
		a=top2->data;
		fwrite(&a,sizeof(REC),1,f1);
		top2=top2->next;
	}
	fclose(f1);
	return flg;
}
