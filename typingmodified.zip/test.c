#include"Record.h"
#include<conio.h>
void main()
{
	print();
	getch();
}
