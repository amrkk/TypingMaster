package model;

public class Paragraph 
{
	String para;
	int paraID;
	int words;
	public int getWords() {
		return words;
	}
	public void setWords(int words) {
		this.words = words;
	}
	public String getPara() {
		return para;
	}
	public void setPara(String para) {
		this.para = para;
	}
	public int getParaID() {
		return paraID;
	}
	public void setParaID(int paraID) {
		this.paraID = paraID;
	}
	
}
